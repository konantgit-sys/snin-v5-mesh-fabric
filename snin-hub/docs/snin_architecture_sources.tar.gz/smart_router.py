"""Smart Router v2 — 4 канала, маршрутные политики, самообучение.

Каналы доставки:
  direct  — TCP напрямую к агенту (IP из DHT)          — ~2ms
  mesh    — Content Router → Route Engine → relay-mesh   — ~100ms
  gossip  — Broadcast через 5 gossip шардов (fan-out ×3)  — ~50ms  
  nostr   — Nostr Gateway → 21 публичный релей           — ~1-5s

Маршрутные политики (правила из Redis policy:routes:{kind}):
  kind:39000 (heartbeat)    → gossip:0.9, mesh:0.1
  kind:39001 (DHT)          → gossip:0.7, direct:0.3
  kind:39002 (content)      → mesh:0.6, nostr:0.4
  kind:39010-39025 (DAO)    → mesh:1.0 (только надёжный)
  kind:1 (Nostr text)       → nostr:1.0
  kind:30000 (market)       → mesh:0.5, gossip:0.5

Формат на вход (TCP :9932, line-based JSON):
  {
    "from": "agent_name",
    "to": "target_agent",
    "kind": 39002,
    "pubkey": "hex",
    "payload": {"text": "..."},
    "meta": { "priority": "high|normal|low", "channel": "auto|direct|mesh|gossip|nostr",
              "ttl": 60, "max_hops": 3, "ack": true }
  }
"""

import asyncio
# import uvloop (disabled)
# asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
import orjson as json
import time
import os
import sys
import hashlib
import random
from collections import defaultdict, deque

from gossip_stream import GossipStream
from graceful_degradation import GracefulDegradation

# ═══ Фаза 1: Reputation-weighted routing ═══
try:
    from reputation import get_reputation_for_pubkey, get_all_reputations
    REPUTATION_ENABLED = True
except Exception:
    REPUTATION_ENABLED = False

def _get_reputation_weight(pubkey: str) -> float:
    """Получить вес репутации для pubkey. 0.0-1.0."""
    if not REPUTATION_ENABLED:
        return 0.5
    try:
        rep = get_reputation_for_pubkey(pubkey)
        return rep.get("score", 0.5)
    except Exception:
        return 0.5

# ═══ Фаза 6: In-memory Circuit Breaker ═══
class InMemoryCircuitBreaker:
    """Pure Python CB — никакого Redis на горячем пути.
    
    Sliding window: deque(timestamps) per channel.
    Incident: >500ms latency → запись в deque.
    Block: 3+ incidents в окне 60s → блок на 30s.
    """
    
    def __init__(self):
        self._incidents: dict[str, deque] = {}
        self._blocked_until: dict[str, float] = {}
        self.latency_threshold_ms = 500
        self.incident_limit = 3
        self.incident_window = 60
        self.block_ttl = 30
    
    def record_incident(self, channel: str) -> bool:
        """Записать инцидент. Вернёт True если канал заблокирован."""
        now = time.time()
        if channel not in self._incidents:
            self._incidents[channel] = deque(maxlen=100)
        
        inc = self._incidents[channel]
        inc.append(now)
        
        # Sliding window: удаляем старше 60s
        while inc and inc[0] < now - self.incident_window:
            inc.popleft()
        
        if len(inc) >= self.incident_limit:
            self._blocked_until[channel] = now + self.block_ttl
            inc.clear()
            return True
        return False
    
    def is_blocked(self, channel: str) -> bool:
        if channel not in self._blocked_until:
            return False
        if time.time() < self._blocked_until[channel]:
            return True
        # Unblock автоматически при истечении TTL
        del self._blocked_until[channel]
        return False
    
    def get_blocked(self) -> list[str]:
        now = time.time()
        return [ch for ch, until in self._blocked_until.items() if now < until]
    
    def force_recovery(self, channel: str):
        """Принудительно снять блокировку канала."""
        self._blocked_until.pop(channel, None)
    
    def reset(self, channel: str):
        """Полный сброс: очистить инциденты и блокировку."""
        self._incidents.pop(channel, None)
        self._blocked_until.pop(channel, None)


# ═══ Фаза 0: Ed25519 verify (0.05ms) ═══
import json as _std_json
def verify_ed25519(pubkey_hex: str, payload: dict, sig_hex: str) -> bool:
    """Верифицировать Ed25519 подпись пакета. 0.05ms."""
    try:
        from cryptography.hazmat.primitives.asymmetric import ed25519
        vk_bytes = bytes.fromhex(pubkey_hex)
        vk = ed25519.Ed25519PublicKey.from_public_bytes(vk_bytes)
        message = _std_json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        sig = bytes.fromhex(sig_hex)
        vk.verify(sig, message)
        return True
    except Exception:
        return False


# ─── Настройки ──────────────────────────────────────────────────────────
LISTEN_HOST = "0.0.0.0"
LISTEN_PORT = 9932

# Адреса каналов
CR_HOST, CR_PORT = "127.0.0.1", 9920
NOSTR_GW_HOST = "127.0.0.1"
NOSTR_GW_PORTS = [9941, 9942, 9943, 9944, 9945]  # 5 bridge shards
GOSSIP_PORTS = [9100, 9101, 9102, 9103, 9104]
CR_V2_PORT = 9920  # Content Router v2

# Phase 3: Unix sockets для внутренней коммуникации
UNIX_SOCK_DIR = "/tmp/snin"
UNIX_CR_SOCK = f"{UNIX_SOCK_DIR}/cr.sock"
UNIX_NOSTR_SOCK = f"{UNIX_SOCK_DIR}/nostr.sock"
UNIX_GOSSIP_SOCKS = [f"{UNIX_SOCK_DIR}/gossip_{i}.sock" for i in range(5)]
UNIX_SR_SOCK = f"{UNIX_SOCK_DIR}/sr.sock"
ACK_CONNECT_TIMEOUT = 5  # таймаут на коннект (Unix) перед fallback к TCP
HEALTH_PORT = 9933  # Phase 4: health check endpoint

# Redis (lazy import в aredis())
REDIS_CLIENT = None
_GLOBAL_ROUTER = None  # глобальный синглтон SmartRouter (in-memory best_channel)

def _get_router():
    """Вернуть глобальный синглтон SmartRouter."""
    return _GLOBAL_ROUTER

# ─── Маршрутная таблица ────────────────────────────────────────────────
ROUTE_HISTORY_KEY = "route:history:{}:{}"
ROUTE_BEST_KEY = "route:best:{}"
ROUTE_STATS_KEY = "route:stats:{}:{}"
POLICY_KEY = "policy:routes"  # Hash: {kind_range: channel_weights_json}
TC_POLICY_KEY = "tc:policy:{}"   # traffic_class → channel weights
TC_HISTORY_KEY = "tc:history:{}:{}"  # tc:history:{traffic_class}:{channel}
TC_BEST_KEY = "tc:best:{}"       # traffic_class → best channel
TC_STATS_KEY = "tc:stats:{}:{}"  # tc:stats:{traffic_class}:{channel}

# Traffic Class → default channel mapping
TRAFFIC_CLASSES = {
    "agent-to-agent": {"gossip": 0.6, "mesh": 0.4},
    "iot":            {"content_router": 0.8, "mesh": 0.2},
    "gossip_data":    {"gossip_data": 1.0, "mesh": 0.5, "gossip": 0.3},
    "nostr-out":      {"nostr": 0.9, "mesh": 0.1},
    "content":        {"mesh": 0.5, "content_router": 0.5},
    "payment":        {"chequebook": 0.5, "mesh": 0.4, "gossip": 0.1},
    "dao":            {"mesh": 1.0, "chequebook": 0.1},
}

KIND_TO_TRAFFIC_CLASS = {
    39000: "agent-to-agent",  # heartbeat
    39001: "agent-to-agent",  # DHT
    39003: "iot",             # External Gateway
    39004: "gossip_data",     # Gossip Data Channel (V8)
    39005: "agent-to-agent",  # health
    39006: "agent-to-agent",  # decision
    39010: "dao",             # DAO proposals
    30000: "payment",         # payments
    1:     "nostr-out",       # Nostr notes
    42:    "nostr-out",       # Nostr channels
    7:     "nostr-out",       # Nostr reactions
}

def classify_traffic(kind: int, meta: dict = None) -> str:
    """Классифицировать тип трафика по kind + meta.
    
    Если meta содержит явный traffic_class — используем его.
    Иначе — определяем по kind.
    """
    if meta and isinstance(meta, dict):
        tc = meta.get("traffic_class", "")
        if tc in TRAFFIC_CLASSES:
            return tc
    return KIND_TO_TRAFFIC_CLASS.get(kind, "content")

# ═══ Фаза 6: In-memory Circuit Breaker (см. класс InMemoryCircuitBreaker) ═══
# CB больше не использует Redis на горячем пути.
# Всё в памяти: sliding window deque + dict для блокировок.

# ═══ Фаза 2: Backpressure ═══
BP_MAX_CONCURRENT = 100                  # макс одновременных подключений
BP_MAX_QUEUE_TIME = 0.5                  # 500ms — max время обработки
BP_RETRY_AFTER_SEC = 5                   # retry_after для клиента


async def aredis():
    global REDIS_CLIENT
    if REDIS_CLIENT is None:
        try:
            import redis.asyncio as redis_py
            REDIS_CLIENT = redis_py.Redis(host='localhost', port=6379, db=0,
                                          socket_connect_timeout=1, socket_timeout=2,
                                          decode_responses=True)
            await REDIS_CLIENT.ping()
        except Exception:
            pass
    return REDIS_CLIENT


# ─── Маршрутные политики ───────────────────────────────────────────────
async def apply_policies():
    """Записать дефолтные политики в Redis, если их нет."""
    r = await aredis()
    if not r:
        return

    defaults = {
        "39000": json.dumps({"gossip": 0.9, "mesh": 0.1}),
        "39001": json.dumps({"gossip": 0.7, "direct": 0.3}),
        "39002": json.dumps({"mesh": 1.0}),
        "39003": json.dumps({"mesh": 0.5, "gossip": 0.5}),
        "39004": json.dumps({"mesh": 0.8, "gossip_data": 1.0, "gossip": 0.3}),
        "39010_39025": json.dumps({"mesh": 1.0}),
        "30000": json.dumps({"chequebook": 0.5, "mesh": 0.4, "gossip": 0.1}),
        "1": json.dumps({"nostr": 1.0}),
        "default": json.dumps({"mesh": 0.7, "gossip": 0.3}),
    }

    for kind_range, weights in defaults.items():
        exists = await r.hget(POLICY_KEY, kind_range)
        if exists is None:
            await r.hset(POLICY_KEY, kind_range, weights)
            print(f"[Policies] ✅ Default policy set: kind {kind_range} → {weights}")
    
    # Traffic Class policies
    for tc, weights in TRAFFIC_CLASSES.items():
        key = TC_POLICY_KEY.format(tc)
        exists = await r.get(key)
        if exists is None:
            await r.setex(key, 86400, json.dumps(weights))
            print(f"[Policies] ✅ TC policy: {tc} → {weights}")


async def get_policy_for_kind(kind: int) -> dict:
    """Вернуть словарь каналов с весами для данного kind."""
    r = await aredis()
    if r:
        # Сначала точное совпадение
        raw = await r.hget(POLICY_KEY, str(kind))
        if raw:
            return json.loads(raw)
        # Диапазон
        all_policies = await r.hgetall(POLICY_KEY)
        for key, raw in all_policies.items():
            if "_" in key:
                parts = key.split("_")
                try:
                    lo, hi = int(parts[0]), int(parts[1])
                    if lo <= kind <= hi:
                        return json.loads(raw)
                except (ValueError, IndexError):
                    continue
        # Default
        raw = await r.hget(POLICY_KEY, "default")
        if raw:
            return json.loads(raw)
    return {"mesh": 1.0}


async def pick_channel_from_policy(policy: dict, agent_id: str) -> str:
    """Выбрать канал из политики по весам (с учётом self-learning)."""
    r = await aredis()
    best = None
    if r:
        best = await r.get(ROUTE_BEST_KEY.format(agent_id))

    # Если best канал есть в политике — используем его
    if best and best in policy:
        return best

    # Иначе — выбираем случайно по весам
    channels = list(policy.keys())
    weights = [policy[c] for c in channels]
    return random.choices(channels, weights=weights, k=1)[0]


async def get_best_channel(agent_id: str) -> str:
    """Лучший канал для агента: in-memory приоритет над Redis."""
    router = _get_router()  # глобальный синглтон
    if router and agent_id in router._best_channel:
        return router._best_channel[agent_id]
    if router and "default" in router._best_channel:
        return router._best_channel["default"]
    r = await aredis()
    if r:
        best = await r.get(ROUTE_BEST_KEY.format(agent_id))
        if best:
            return best
    return "mesh"


async def record_route(agent_id: str, channel: str, latency_ms: float, success: bool):
    r = await aredis()
    if r is None:
        return
    key = ROUTE_HISTORY_KEY.format(agent_id, channel)
    now = time.time()
    await r.zadd(key, {f"{now}:{latency_ms:.1f}": latency_ms})
    await r.zremrangebyrank(key, 0, -101)
    await r.expire(key, 86400)

    scores = await r.zrange(key, 0, -1, withscores=True)
    avg = sum(s[1] for s in scores) / len(scores) if scores else latency_ms

    stats_key = ROUTE_STATS_KEY.format(agent_id, channel)
    if success:
        await r.hincrby(stats_key, "sent", 1)
    else:
        await r.hincrby(stats_key, "failed", 1)
    await r.hset(stats_key, "avg_latency", f"{avg:.1f}")
    await r.expire(stats_key, 86400)

    current_best = await r.get(ROUTE_BEST_KEY.format(agent_id))
    if current_best is None:
        await r.set(ROUTE_BEST_KEY.format(agent_id), channel)
        await r.expire(ROUTE_BEST_KEY.format(agent_id), 86400)
    elif success and current_best != channel:
        # Сравниваем: если новый канал быстрее — переключаем
        curr_avg = await r.hget(ROUTE_STATS_KEY.format(agent_id, current_best), "avg_latency")
        if curr_avg:
            try:
                if avg < float(curr_avg) * 0.8:  # на 20% быстрее = переключение
                    await r.set(ROUTE_BEST_KEY.format(agent_id), channel)
            except ValueError:
                pass


# ═══ Фаза 2: Circuit Breaker ═══
async def cb_record_incident(channel: str):
    """Записать инцидент (latency >500ms) для канала."""
    r = await aredis()
    if not r:
        return
    now = time.time()
    key = CB_INCIDENT_KEY.format(channel, "all")
    await r.zadd(key, {f"{now}": now})
    # Чистим старые (>60 сек)
    await r.zremrangebyscore(key, 0, now - CB_INCIDENT_WINDOW)
    await r.expire(key, 300)
    # Считаем в окне
    count = await r.zcard(key)
    if count >= CB_INCIDENT_LIMIT:
        # Блокируем канал
        block_key = CB_BLOCKED_KEY.format(channel)
        await r.setex(block_key, CB_BLOCK_TTL, "1")
        print(f"[CB] 🛑 Channel '{channel}' BLOCKED for {CB_BLOCK_TTL}s ({count} incidents)")
        await r.delete(key)  # Сброс счётчика
        return True
    return False


async def cb_is_blocked(channel: str) -> bool:
    """Проверить, заблокирован ли канал."""
    r = await aredis()
    if not r:
        return False
    return (await r.exists(CB_BLOCKED_KEY.format(channel))) > 0


async def cb_get_blocked_channels() -> list:
    """Список заблокированных каналов."""
    r = await aredis()
    if not r:
        return []
    keys = await r.keys(CB_BLOCKED_KEY.format("*"))
    return [k.split(":")[-1] for k in keys]


# ═══ Фаза 3: Consistent Hashing для gossip ═══
N_SHARDS = len(GOSSIP_PORTS)

def gossip_shard_for(pubkey: str) -> int:
    """Выбрать шард по pubkey через consistent hashing."""
    if not pubkey or pubkey == "?" or len(pubkey) < 8:
        return random.randint(0, N_SHARDS - 1)
    # MD5 хеш pubkey → индекс шарда
    h = hashlib.md5(pubkey.encode()).hexdigest()
    return int(h[:8], 16) % N_SHARDS


# ─── Smart Router ──────────────────────────────────────────────────────
class SmartRouter:
    def __init__(self):
        self.stats = defaultdict(int)
        self.stats["start_time"] = time.time()
        self._deg = GracefulDegradation()
        self._cr_writer = None
        self._nostr_writers = []  # 5 bridge shards
        self._gossip_writers = []
        self._gossip_stream = None  # V8: GossipStream instance
        # Self-learning
        self._last_learning = time.time()
        self._learning_interval = 15  # сек
        self._channel_health = {
            "mesh": {"ok": 0, "fail": 0, "avg_ms": 0},
            "gossip": {"ok": 0, "fail": 0, "avg_ms": 0},
            "nostr": {"ok": 0, "fail": 0, "avg_ms": 0},
            "direct": {"ok": 0, "fail": 0, "avg_ms": 0},
        }
        # ═══ Фаза 2: Circuit Breaker + Backpressure ═══
        self._cb = InMemoryCircuitBreaker()
        self._concurrent = 0
        self._bp_threshold_reached = False
        # ═══ Фаза 6.2: In-memory Policy Cache ═══
        self._policy_cache: dict[str, dict] = {}
        self._policy_cache_loaded = False
        self._best_channel: dict[str, str] = {}
        # ═══ Фаза 6.3: Deferred Route Stats ═══
        self._rs_sent: dict[str, dict[str, int]] = {}
        self._rs_failed: dict[str, dict[str, int]] = {}
        self._rs_lat: dict[str, dict[str, list[float]]] = {}
        self._rs_last_flush = time.time()
        # ═══ Вектор 3: Traffic Class Stats (in-memory) ═══
        self._tc_sent: dict[str, int] = {}
        self._tc_failed: dict[str, int] = {}
        self._tc_lat: dict[str, list[float]] = {}
        # ═══ Фаза 6.7: Batch Mesh Drain ═══
        self._mesh_buf = bytearray()
        self._last_mesh_drain = 0.0
        self._mesh_drain_interval = 0.01  # 10ms
        # ═══ Фаза 1.1: Pending queue для mesh при отвале CR ═══
        self._pending_mesh_queue: list[dict] = []  # накопленные сообщения
        self._pending_mesh_max = 1000               # лимит очереди
        # ═══ Фаза 1.2: CB recovery counter ═══
        self._cb_recovery_count: dict[str, int] = {}  # channel → успешных drain подряд
        self._cb_recovery_threshold = 5                # после скольких снять блокировку
        self._cr_v2_writer = None  # Content Router v2 (:9920)
        # ═══ Фаза 1: DHT Kademlia ═══
        self._dht = None
        # ═══ Фаза 8: Event subscribers (push-канал для агентов) ═══
        self._event_subscribers: dict[int, tuple] = {}  # id → (writer, agent_name)
        self._sub_next_id = 0

    # ═══ Фаза 6.2: In-memory Policy Cache ═══
    async def _load_policy_cache(self):
        """Загрузить все политики из Redis в in-memory cache.
        Вызывается при старте и раз в 60 секунд в self_learning_loop.
        """
        r = await aredis()
        if not r:
            return
        try:
            all_raw = await r.hgetall(POLICY_KEY)
            cache = {}
            for key, raw in all_raw.items():
                try:
                    # orjson требует bytes; Redis с decode_responses=True отдаёт str
                    data = raw.encode() if isinstance(raw, str) else raw
                    cache[key] = json.loads(data)
                except Exception:
                    cache[key] = {"mesh": 1.0}  # fallback
            self._policy_cache = cache
            self._policy_cache_loaded = True
        except Exception as e:
            print(f"[PolicyCache] Error loading: {e}")

    def get_policy(self, kind: int) -> dict:
        """In-memory: вернуть политику для kind без Redis.
        Exact match → Range match → Default.
        Если кэш пуст — fallback на Redis функцию.
        """
        sk = str(kind)

        # Exact match
        if sk in self._policy_cache:
            return self._policy_cache[sk]

        # Range match (39010_39025 → mesh:1.0)
        for key, weights in self._policy_cache.items():
            if "_" in key:
                parts = key.split("_")
                try:
                    lo, hi = int(parts[0]), int(parts[1])
                    if lo <= kind <= hi:
                        return weights
                except (ValueError, IndexError):
                    continue

        # Default
        return self._policy_cache.get("default", {"mesh": 1.0})

    async def _sync_best_channels(self):
        """Раз в 60 сек: синхронизировать best_channel из Redis.
        Только для агентов с >10 маршрутами — не на горячем пути.
        """
        r = await aredis()
        if not r:
            return
        try:
            keys = await r.keys("route:best:*")
            for k in keys:
                agent = k.split(":")[-1]
                if agent:
                    ch = await r.get(k)
                    if ch:
                        self._best_channel[agent] = ch
        except Exception as e:
            print(f"[SyncBest] Error: {e}")

    # ═══ Фаза 6.3: Deferred Route Stats ═══
    # ═══ Вектор 3: Self-Learning по traffic_class ═══
    async def _get_tc_best(self, traffic_class: str) -> str | None:
        """Лучший канал для данного traffic_class из Redis."""
        r = await aredis()
        if r:
            return await r.get(TC_BEST_KEY.format(traffic_class))
        return None
    
    def _record_tc(self, traffic_class: str, channel: str, latency_ms: float, success: bool):
        """Сохранить статистику по traffic_class (in-memory, flush в Redis)."""
        key = f"tc:{traffic_class}:{channel}"
        if success:
            self._tc_sent[key] = self._tc_sent.get(key, 0) + 1
            lats = self._tc_lat.get(key)
            if lats is None:
                self._tc_lat[key] = lats = []
            if len(lats) < 50:
                lats.append(latency_ms)
        else:
            self._tc_failed[key] = self._tc_failed.get(key, 0) + 1
    
    def _record_route(self, agent_id: str, channel: str, latency_ms: float, success: bool):
        """In-memory: синхронный append в буфер, 0 Redis на горячем пути.
        Флашится раз в 30 сек через _flush_route_stats.
        """
        key = f"{agent_id}:{channel}"
        if success:
            self._rs_sent[key] = self._rs_sent.get(key, 0) + 1
            lats = self._rs_lat.get(key)
            if lats is None:
                self._rs_lat[key] = lats = []
            if len(lats) < 50:
                lats.append(latency_ms)
        else:
            self._rs_failed[key] = self._rs_failed.get(key, 0) + 1

    async def _flush_route_stats(self):
        """Раз в 30 сек: batch запись накопленной статистики в Redis."""
        r = await aredis()
        if not r or (not self._rs_sent and not self._rs_failed):
            self._rs_last_flush = time.time()
            return
        try:
            pipe = r.pipeline()
            for key, count in self._rs_sent.items():
                agent, ch = key.split(":", 1)
                pipe.hincrby(ROUTE_STATS_KEY.format(agent, ch), "sent", count)
            for key, count in self._rs_failed.items():
                agent, ch = key.split(":", 1)
                pipe.hincrby(ROUTE_STATS_KEY.format(agent, ch), "failed", count)
            for key, lats in self._rs_lat.items():
                if lats:
                    agent, ch = key.split(":", 1)
                    avg = sum(lats) / len(lats)
                    pipe.hset(ROUTE_STATS_KEY.format(agent, ch), "avg_latency", f"{avg:.1f}")
                    pipe.expire(ROUTE_STATS_KEY.format(agent, ch), 86400)
                    # ═══ Дыра C fix: сохраняем route:history и route:best ═══
                    now = time.time()
                    pipe.zadd(ROUTE_HISTORY_KEY.format(agent, ch), {f"{now}:{avg:.1f}": avg})
                    pipe.zremrangebyrank(ROUTE_HISTORY_KEY.format(agent, ch), 0, -101)
                    pipe.expire(ROUTE_HISTORY_KEY.format(agent, ch), 86400)
            await pipe.execute()
            
            # route:best — лучший канал по avg_latency
            for key in self._rs_lat:
                if key:
                    agent, ch = key.split(":", 1)
                    lats = self._rs_lat[key]
                    if lats:
                        avg = sum(lats) / len(lats)
                        current_best = await r.get(ROUTE_BEST_KEY.format(agent))
                        if current_best is None:
                            await r.setex(ROUTE_BEST_KEY.format(agent), 86400, ch)
                        elif ch == current_best:
                            pass
                        else:
                            curr_avg = await r.hget(ROUTE_STATS_KEY.format(agent, current_best), "avg_latency")
                            if curr_avg and float(curr_avg) > 0:
                                if avg < float(curr_avg) * 0.8:
                                    await r.setex(ROUTE_BEST_KEY.format(agent), 86400, ch)
            
            # ═══ Вектор 3: Flush TC stats в Redis ═══
            tc_pipe = r.pipeline()
            for key, count in self._tc_sent.items():
                # key = tc:{traffic_class}:{channel}
                parts = key.split(":", 2)
                if len(parts) == 3:
                    traffic_class, ch = parts[1], parts[2]
                    tc_pipe.hincrby(TC_STATS_KEY.format(traffic_class, ch), "sent", count)
            for key, count in self._tc_failed.items():
                parts = key.split(":", 2)
                if len(parts) == 3:
                    traffic_class, ch = parts[1], parts[2]
                    tc_pipe.hincrby(TC_STATS_KEY.format(traffic_class, ch), "failed", count)
            for key, lats in self._tc_lat.items():
                if lats:
                    parts = key.split(":", 2)
                    if len(parts) == 3:
                        traffic_class, ch = parts[1], parts[2]
                        avg = sum(lats) / len(lats)
                        tc_pipe.hset(TC_STATS_KEY.format(traffic_class, ch), "avg_latency", f"{avg:.1f}")
                        tc_pipe.expire(TC_STATS_KEY.format(traffic_class, ch), 86400)
                        # TC history (sorted set для self-learning)
                        now = time.time()
                        tc_pipe.zadd(TC_HISTORY_KEY.format(traffic_class, ch), {f"{now}:{avg:.1f}": avg})
                        tc_pipe.zremrangebyrank(TC_HISTORY_KEY.format(traffic_class, ch), 0, -101)
                        tc_pipe.expire(TC_HISTORY_KEY.format(traffic_class, ch), 86400)
            await tc_pipe.execute()
            
            # Обновляем TC_BEST в self_learning_loop (сравниваем avg_latency по каналам)
            tc_best_updates = {}
            for key in self._tc_lat:
                parts = key.split(":", 2)
                if len(parts) == 3:
                    traffic_class, ch = parts[1], parts[2]
                    lats = self._tc_lat[key]
                    if lats:
                        avg = sum(lats) / len(lats)
                        if traffic_class not in tc_best_updates or avg < tc_best_updates[traffic_class][1]:
                            tc_best_updates[traffic_class] = (ch, avg)
            for tc, (best_ch, avg_lat) in tc_best_updates.items():
                current_best = await r.get(TC_BEST_KEY.format(tc))
                if current_best != best_ch:
                    await r.setex(TC_BEST_KEY.format(tc), 86400, best_ch)
                    print(f"[TC] {tc} → {best_ch} ({avg_lat:.0f}ms)")
            
            self._rs_sent.clear()
            self._rs_failed.clear()
            self._rs_lat.clear()
            self._tc_sent.clear()
            self._tc_failed.clear()
            self._tc_lat.clear()
        except Exception as e:
            print(f"[FlushRoute] Error: {e}")
        self._rs_last_flush = time.time()

    async def connect_channel(self, host, port, name, unix_path=None):
        """Connect to channel: Unix socket (Phase 3) → TCP fallback."""
        # Unix first
        if unix_path:
            for _ in range(3):
                try:
                    r, w = await asyncio.wait_for(
                        asyncio.open_unix_connection(unix_path),
                        timeout=ACK_CONNECT_TIMEOUT)
                    print(f"[Router] ✅ Channel '{name}' (Unix)")
                    return w
                except (FileNotFoundError, ConnectionRefusedError, asyncio.TimeoutError, OSError):
                    if _ == 0:
                        print(f"[Router] ⏳ '{name}' Unix not ready, fallback TCP...")
                    await asyncio.sleep(1)
        
        # TCP fallback
        for attempt in range(5):
            try:
                r, w = await asyncio.open_connection(host, port)
                print(f"[Router] ✅ Channel '{name}' ({host}:{port})")
                return w
            except ConnectionRefusedError:
                if attempt == 0:
                    print(f"[Router] ⏳ '{name}' not ready ({host}:{port})...")
                await asyncio.sleep(2)
        print(f"[Router] ⚠️ Cannot connect '{name}'")
        return None

    async def ensure_channels(self):
        """Параллельное подключение ко всем каналам (Unix → TCP fallback)."""
        channels = [
            self.connect_channel(CR_HOST, CR_PORT, "mesh", UNIX_CR_SOCK),
        ]
        # Gossip shards
        for i, (port, usock) in enumerate(zip(GOSSIP_PORTS, UNIX_GOSSIP_SOCKS)):
            channels.append(self.connect_channel("127.0.0.1", port, f"gossip:{i}", usock))
        
        results = await asyncio.gather(*channels)
        
        self._cr_writer = results[0]
        self._gossip_writers = [w for w in results[1:] if w is not None]
        
        # ═══ Connect to all 5 nostr bridge shards ═══
        self._nostr_writers = []
        for i, port in enumerate(NOSTR_GW_PORTS):
            try:
                r, w = await asyncio.wait_for(
                    asyncio.open_connection(NOSTR_GW_HOST, port), timeout=2
                )
                self._nostr_writers.append(w)
                print(f"[Router] ✅ nostr shard-{i} connected (:{port})")
            except Exception:
                print(f"[Router] ⏳ nostr shard-{i} not ready (:{port}) — will retry on-demand")
        
        # Content Router v2 (:9920)
        try:
            r, w = await asyncio.wait_for(
                asyncio.open_connection("127.0.0.1", CR_V2_PORT), timeout=2
            )
            self._cr_v2_writer = w
            print(f"[Router] ✅ CR v2 connected (:{CR_V2_PORT})")
        except Exception as e:
            print(f"[Router] ⚠️ CR v2 not available: {e}")
        
        print(f"[Router]    Channels: mesh {'✓' if self._cr_writer else '✗'} "
              f"nostr({len(self._nostr_writers)}/5) "
              f"gossip({len(self._gossip_writers)}/5) direct ✓")
    
    async def _reconnect_gossip_shard(self, shard_idx: int):
        """Переподключение к gossip шарду при падении writer."""
        if shard_idx < 0 or shard_idx >= 5:
            return
        port = 9100 + shard_idx
        print(f"[Router] 🔄 Reconnecting gossip shard {shard_idx} (:{port})...")
        for attempt in range(5):
            try:
                r, w = await asyncio.wait_for(
                    asyncio.open_connection("127.0.0.1", port), timeout=2
                )
                self._gossip_writers[shard_idx] = w
                print(f"[Router] ✅ gossip shard {shard_idx} reconnected")
                return
            except (ConnectionRefusedError, OSError, asyncio.TimeoutError) as e:
                await asyncio.sleep(2)
        print(f"[Router] ⚠️ gossip shard {shard_idx} reconnect failed")
        self._gossip_writers[shard_idx] = None

    async def _reconnect_mesh(self):
        """Переподключение к mesh (CRV2 Unix socket) с exponential backoff.
        
        Backoff: 1 → 2 → 4 → 8 → 15 → 30 (cap) секунд.
        После восстановления — отправляет все накопленные сообщения.
        """
        backoff = [1, 2, 4, 8, 15, 30]
        print(f"[Router] 🔄 Reconnecting mesh (CRV2 Unix socket)...")
        for attempt, delay in enumerate(backoff):
            try:
                r, w = await asyncio.wait_for(
                    asyncio.open_unix_connection("/tmp/snin/cr.sock"), timeout=3
                )
                self._cr_writer = w
                print(f"[Router] ✅ mesh (CRV2) reconnected (attempt {attempt + 1})")
                # Сбросить накопленные сообщения
                await self._flush_pending_queue()
                return
            except (FileNotFoundError, ConnectionRefusedError, OSError, asyncio.TimeoutError) as e:
                if attempt == 0:
                    print(f"[Router] ⏳ mesh (CRV2) not ready, retrying...")
                elif attempt < len(backoff) - 1:
                    print(f"[Router] ⏳ mesh retry {attempt + 1}/{len(backoff)} in {delay}s...")
                await asyncio.sleep(delay)
        print(f"[Router] ⚠️ mesh (CRV2) reconnect failed after {len(backoff)} attempts")
        self._cr_writer = None

    async def _flush_pending_queue(self):
        """Отправить все накопленные сообщения после восстановления mesh."""
        if not self._pending_mesh_queue:
            return
        count = len(self._pending_mesh_queue)
        print(f"[Router] 📦 Flushing {count} pending mesh messages...")
        to_send = list(self._pending_mesh_queue)
        self._pending_mesh_queue.clear()
        
        if self._cr_writer:
            payload = b"".join(json.dumps(m) + b"\n" for m in to_send)
            try:
                self._cr_writer.write(payload)
                await asyncio.wait_for(self._cr_writer.drain(), timeout=5)
                print(f"[Router] ✅ {count} pending messages flushed")
            except Exception as e:
                self._pending_mesh_queue.extend(to_send)
                print(f"[Router] ⚠️ Flush failed: {e}, {len(self._pending_mesh_queue)} in queue")
                self._cr_writer = None
                asyncio.ensure_future(self._reconnect_mesh())

    # ═══ V8: DHT → GossipStream peer discovery ═══
    async def _dht_scan_peers(self):
        """Сканировать DHT в Redis на агентов с relay_addr.
        Для каждого найденного пира — подключить GossipStream.
        """
        if not self._gossip_stream:
            return

        r = await aredis()
        if not r:
            return

        try:
            all_agents = await r.hgetall("dht:agents")
            connected = 0
            for pk_hex, raw in all_agents.items():
                try:
                    agent = json.loads(raw)
                except:
                    continue

                relay_addr = agent.get("relay_addr", "")
                if not relay_addr or relay_addr == "127.0.0.1:9105":
                    continue

                peer_id = f"agent:{pk_hex[:16]}"
                if peer_id in self._gossip_stream.pools:
                    continue

                host, port_str = relay_addr.rsplit(":", 1)
                port = int(port_str) if port_str.isdigit() else 9105

                print(f"[Router] 🔗 DHT → GossipStream: {peer_id} ({host}:{port})")
                ok = await self._gossip_stream.add_peer(peer_id, host, port)
                if ok:
                    connected += 1

            if connected:
                print(f"[Router] ✅ GossipStream подключил {connected} пиров из DHT")
        except Exception as e:
            print(f"[Router] ⚠️ DHT scan: {e}")

    async def _dht_scan_loop(self):
        """Периодический DHT scan (каждые 30 сек)."""
        while True:
            await self._dht_scan_peers()
            await asyncio.sleep(30)

    async def send_via_channel(self, channel: str, message: dict) -> dict:
        start = time.time()
        print(f"[Router] 🚀 send_via_channel({channel})")
        result = {"ok": False, "latency_ms": 0, "error": ""}

        # ═══ Фаза 2: проверка Circuit Breaker ═══
        print(f"[Router] 🧪 CB check: channel={channel}, blocked={self._cb.is_blocked(channel)}")
        if self._cb.is_blocked(channel):
            self.stats["cb_blocked"] += 1
            result["error"] = f"circuit_breaker: {channel} blocked"
            latency_ms = (time.time() - start) * 1000
            result["latency_ms"] = round(latency_ms, 1)
            return result

        try:
            if channel == "mesh" and self._cr_writer:
                # Фаза 6.7: Batch drain — буферизируем, drain каждые 10ms
                self._mesh_buf.extend(json.dumps(message) + b"\n")
                now = time.time()
                if now - self._last_mesh_drain >= self._mesh_drain_interval:
                    try:
                        self._cr_writer.write(bytes(self._mesh_buf))
                        self._mesh_buf.clear()
                        await asyncio.wait_for(self._cr_writer.drain(), timeout=3)
                        self._last_mesh_drain = now
                        result["ok"] = True
                        # ═══ CB recovery: увеличить счётчик успешных ═══
                        self._cb_recovery_count["mesh"] = self._cb_recovery_count.get("mesh", 0) + 1
                        if self._cb_recovery_count["mesh"] >= self._cb_recovery_threshold:
                            if self._cb.is_blocked("mesh"):
                                self._cb._blocked_until.pop("mesh", None)
                                print(f"[Router] 🩺 CB mesh auto-recovered ({self._cb_recovery_count['mesh']} successful)")
                            self._cb_recovery_count["mesh"] = 0
                    except (ConnectionResetError, BrokenPipeError, OSError, asyncio.TimeoutError) as _eb:
                        # Не чистим буфер — сохраняем сообщение в pending queue
                        pending_msg = json.loads(self._mesh_buf.decode())
                        self._mesh_buf.clear()
                        self._cr_writer = None
                        self.stats["mesh_error"] += 1
                        result["error"] = f"mesh writer dead: {_eb}"
                        # ═══ Сохраняем в очередь неотправленных ═══
                        if len(self._pending_mesh_queue) < self._pending_mesh_max:
                            self._pending_mesh_queue.append(pending_msg)
                            print(f"[Router] 📥 Saved to pending queue ({len(self._pending_mesh_queue)})")
                        else:
                            print(f"[Router] ⚠️ Pending queue full, dropping message")
                        asyncio.ensure_future(self._reconnect_mesh())
                
                # ═══ Форвард подписчикам (агентам) — ВСЕГДА, не только при успешном drain ═══
                if self._event_subscribers:
                    await self._push_to_subscribers(message)
            elif channel == "mesh":  # _cr_writer is None, пробуем восстановить
                result = {"ok": False, "error": "mesh writer not connected"}
                asyncio.ensure_future(self._reconnect_mesh())

            elif channel == "nostr":
                # ═══ Multi-shard: write to all connected nostr bridges ═══
                writers = self._nostr_writers
                if not writers:
                    # Попытка подключить хотя бы один шард
                    print(f"[Router] 🔴 No nostr writers, trying shard-0...")
                    try:
                        r, w = await asyncio.wait_for(
                            asyncio.open_connection(NOSTR_GW_HOST, NOSTR_GW_PORTS[0]), timeout=3
                        )
                        self._nostr_writers.append(w)
                        writers = self._nostr_writers
                        print(f"[Router] ✅ nostr shard-0 connected on-demand")
                    except Exception as e:
                        self.stats["chan_fail:nostr"] += 1
                        result["error"] = f"nostr connect all failed: {e}"
                        return result
                
                # Конвертируем payload в строку (агенты шлют bytes и другие типы)
                try:
                    payload = message.get("payload", {})
                    if isinstance(payload, (bytes, bytearray)):
                        content_str = payload.decode("utf-8", errors="replace")
                    elif isinstance(payload, str):
                        content_str = payload
                    elif isinstance(payload, dict):
                        print(f"[Router] 🐛 payload type={type(payload).__name__} repr={type(payload).__repr__} keys={list(payload.keys())[:3] if hasattr(payload,'keys') else '?'}")
                        try:
                            content_str = json.dumps(payload, ensure_ascii=False)
                        except TypeError:
                            # orjson doesn't support ensure_ascii
                            content_str = json.dumps(payload)
                    else:
                        content_str = str(payload)
                except Exception as e:
                    content_str = str(payload)
                    print(f"[Router] ⚠️ payload convert error for nostr: {type(e).__name__}: {e}")
                
                nostr_msg = {
                    "kind": 1,
                    "pubkey": message.get("pubkey", "router"),
                    "content": content_str,
                    "created_at": int(time.time()),
                }
                payload_bytes = json.dumps(nostr_msg) + b"\n"  # orjson returns bytes, no .encode/ensure_ascii
                
                # Пишем во все живые шарды параллельно
                ok_count = 0
                dead_writers = []
                for i, w in enumerate(writers):
                    try:
                        w.write(payload_bytes)
                        await asyncio.wait_for(w.drain(), timeout=3)
                        ok_count += 1
                    except (BrokenPipeError, ConnectionResetError, asyncio.TimeoutError, OSError) as e:
                        dead_writers.append(i)
                        print(f"[Router] ⚠️ nostr shard-{i} writer died")
                
                # Убираем мёртвые writer-ы
                for i in reversed(dead_writers):
                    self._nostr_writers.pop(i)
                
                if ok_count > 0:
                    result["ok"] = True
                    result["shards_ok"] = ok_count
                    result["shards_total"] = len(writers) + len(dead_writers)
                else:
                    self.stats["chan_fail:nostr"] += 1
                    result["error"] = "all nostr shards dead"
                    # Попытка переподключить shard-0
                    try:
                        r, w = await asyncio.wait_for(
                            asyncio.open_connection(NOSTR_GW_HOST, NOSTR_GW_PORTS[0]), timeout=3
                        )
                        self._nostr_writers.append(w)
                        print(f"[Router] ✅ nostr shard-0 reconnected")
                    except Exception as ce:
                        print(f"[Router] ❌ nostr reconnect failed: {ce}")

            elif channel == "content_router" and self._cr_v2_writer:
                payload = json.dumps(message) + b"\n"
                try:
                    self._cr_v2_writer.write(payload)
                    await asyncio.wait_for(self._cr_v2_writer.drain(), timeout=3)
                    result["ok"] = True
                except Exception as e:
                    self._cr_v2_writer = None
                    self.stats["chan_fail:cr_v2"] += 1
                    result["error"] = str(e)
            
            # ═══ Вектор 4: ChequeBook канал (payment) ═══
            elif channel == "chequebook":
                kind = message.get("kind", 0)
                if kind == 30000:
                    try:
                        import httpx
                        async with httpx.AsyncClient(timeout=10) as c:
                            # send to ChequeBook API
                            resp = await c.post(
                                "http://127.0.0.1:9916/api/v1/payment",
                                json=message, headers={"Content-Type": "application/json"}
                            )
                            if resp.status_code == 200:
                                result["ok"] = True
                                result["msg"] = "payment processed"
                            else:
                                result["error"] = f"chequebook: {resp.status_code}"
                    except ImportError:
                        # fallback: direct HTTP
                        import urllib.request
                        payload = json.dumps(message)  # orjson returns bytes
                        req = urllib.request.Request(
                            "http://127.0.0.1:9916/api/v1/payment",
                            data=payload,
                            headers={"Content-Type": "application/json"}
                        )
                        try:
                            with urllib.request.urlopen(req, timeout=5) as resp:
                                if resp.status == 200:
                                    result["ok"] = True
                        except Exception as e:
                            result["error"] = f"chequebook: {e}"
                result["ok"] = True  # optimistic — если нет handler на платежи
            
            elif channel == "gossip" and self._gossip_writers:
                gossip_msg = dict(message)
                if "meta" not in gossip_msg:
                    gossip_msg["meta"] = {}
                if isinstance(gossip_msg["meta"], dict):
                    gossip_msg["meta"] = {**gossip_msg["meta"], "origin": "smart_router"}

                # Фаза 3: Consistent Hashing — выбираем шард по pubkey если есть
                target_pubkey = message.get("to") or message.get("pubkey", "")
                gossip_payload = json.dumps(gossip_msg) + b"\n"
                if target_pubkey and len(target_pubkey) > 8:
                    # Directed: шлём в 1 шард (по хешу pubkey)
                    shard_idx = gossip_shard_for(target_pubkey)
                    if shard_idx < len(self._gossip_writers):
                        w = self._gossip_writers[shard_idx]
                        try:
                            w.write(gossip_payload)
                            await asyncio.wait_for(w.drain(), timeout=2)
                            result["ok"] = True
                            self.stats[f"ch_shard:{shard_idx}"] += 1
                        except (asyncio.TimeoutError, Exception) as e:
                            self.stats["gossip_error"] += 1
                            result["error"] = str(e)
                            # Reconnect мёртвого шарда
                            if "closed" in str(e).lower() or "reset" in str(e).lower() or "broken" in str(e).lower():
                                self._gossip_writers[shard_idx] = None
                                asyncio.ensure_future(self._reconnect_gossip_shard(shard_idx))
                    else:
                        result["error"] = f"invalid shard {shard_idx}"
                else:
                    # Broadcast: batch write во все 5 → concurrent drain
                    to_drain = []
                    for idx, w in enumerate(self._gossip_writers):
                        if w is None:
                            continue
                        try:
                            w.write(gossip_payload)
                            to_drain.append(w)
                            result["ok"] = True
                        except Exception as e:
                            self.stats["gossip_error"] += 1
                            if "closed" in str(e).lower() or "reset" in str(e).lower() or "broken" in str(e).lower():
                                self._gossip_writers[idx] = None
                                asyncio.ensure_future(self._reconnect_gossip_shard(idx))
                    # Concurrent drain всех шардов
                    if to_drain:
                        await asyncio.gather(
                            *[asyncio.wait_for(w.drain(), timeout=2) for w in to_drain],
                            return_exceptions=True
                        )
                    self.stats["gossip_broadcast"] += 1

            elif channel == "gossip_data":
                # V8: GossipStream — data channel между реле
                if self._gossip_stream:
                    payload = message.get("payload", message.get("content", {}))
                    if isinstance(payload, str):
                        try:
                            payload = json.loads(payload)
                        except:
                            payload = {"text": payload}
                    bcast = await self._gossip_stream.broadcast(payload)
                    result["ok"] = any(bcast.values()) if bcast else False
                    if bcast:
                        self.stats["gossip_data_sent"] += sum(1 for v in bcast.values() if v)
                else:
                    result["error"] = "gossip_stream not initialized"
                    self.stats["chan_fail:gossip_data"] += 1

            elif channel == "direct":
                to = message.get("to", "")
                r = await aredis()
                if r and to:
                    # DHT lookup: сначала Redis hash, потом старые ключи
                    agent_data = await r.hget(f"dht:agents", to)
                    if not agent_data:
                        agent_data = await r.hget(f"dht:agents", to[:16])
                    if not agent_data:
                        agent_data = await r.get(f"dht:agent:{to[:16]}")
                    if not agent_data:
                        agent_data = await r.get(f"dht:{to[:16]}")
                    if agent_data:
                        info = json.loads(agent_data)
                        ip = info.get("ip", "127.0.0.1")
                        port = info.get("tcp_port", info.get("port", 9932))
                        try:
                            r2, w2 = await asyncio.wait_for(
                                asyncio.open_connection(ip, int(port)), timeout=2
                            )
                            w2.write(json.dumps(message) + b"\n")
                            await w2.drain()
                            w2.close()
                            result["ok"] = True
                        except Exception as e:
                            result["error"] = f"conn: {e}"
                    else:
                        result["error"] = "agent not in DHT"
                else:
                    result["error"] = "no DHT"
            else:
                result["error"] = f"unknown channel '{channel}'"

        except asyncio.TimeoutError:
            result["error"] = f"{channel}_timeout"
            self.stats[f"timeout:{channel}"] += 1
        except Exception as e:
            result["error"] = str(e)

        latency_ms = (time.time() - start) * 1000
        result["latency_ms"] = round(latency_ms, 1)

        # ═══ Фаза 2: Circuit Breaker — инциденты ═══
        # Только если сообщение ДОСТАВЛЕНО, но медленно
        if result["ok"] and latency_ms > self._cb.latency_threshold_ms:
            self._cb.record_incident(channel)
            self.stats[f"cb_incident:{channel}"] += 1
        
        # Ошибка отправки (buffer full, drain timeout) — НЕ инцидент CB
        # Это нормальная backpressure при высокой нагрузке
        # CB сработает отдельно при fail_rate > 50% в self_learning_loop

        # Фаза 1: обновляем health канала в реальном времени
        health = self._channel_health.get(channel)
        if health and channel in ("mesh", "gossip", "nostr", "direct"):
            if result["ok"]:
                health["ok"] += 1
            else:
                health["fail"] += 1
            if result["ok"]:
                prev = health["avg_ms"]
                health["avg_ms"] = prev * 0.9 + latency_ms * 0.1 if prev else latency_ms

        return result

    # ─── Фаза 1: Self-Learning ────────────────────────────────────────
    # ─── Фаза 1: Self-Learning (Redis + in-memory fallback) ────────────
    async def self_learning_loop(self):
        """Каждые N секунд: анализирует маршруты через Redis (или in-memory).
        
        Двухуровневая архитектура:
        1. Redis доступен → используем route:history и tc:stats для точного выбора
        2. Redis недоступен → in-memory _channel_health как fallback
        """
        while True:
            await asyncio.sleep(self._learning_interval)
            try:
                now = time.time()
                r = await aredis()
                changes = []

                # ═══ Блок 1: Circuit Breaker + Channel Health (всегда in-memory) ═══
                for ch, h in self._channel_health.items():
                    total = h["ok"] + h["fail"]
                    if total > 5:
                        fail_rate = h["fail"] / total
                        if fail_rate > 0.5:
                            self._cb.record_incident(ch)
                            changes.append(f"🚨 CB {ch} fail_rate={fail_rate:.0%}")
                        elif fail_rate > 0.3:
                            changes.append(f"❌ {ch} fail_rate={fail_rate:.0%} → congestion")
                        elif h["avg_ms"] > 0 and h["avg_ms"] > 200:
                            changes.append(f"⚠️ {ch} slow={h['avg_ms']:.0f}ms")

                # CB recovery
                for ch in list(self._cb._blocked_until.keys()):
                    if not self._cb.is_blocked(ch):
                        changes.append(f"🔓 CB {ch} → unblocked")

                # ═══ Блок 2: Анализ маршрутов ═══
                if r:
                    # ─── Tier 1: Redis — per-агент статистика ───
                    all_agents = set()
                    for key in await r.keys("route:history:*:*"):
                        parts = key.split(":")
                        if len(parts) >= 4:
                            all_agents.add(parts[2])

                    for agent in list(all_agents)[:50]:
                        best_ch = None
                        best_avg = 9999
                        for ch in ("mesh", "gossip", "nostr", "direct"):
                            stats_key = ROUTE_STATS_KEY.format(agent, ch)
                            stats = await r.hgetall(stats_key)
                            if not stats:
                                continue
                            avg_lat = stats.get("avg_latency")
                            if avg_lat and avg_lat != "?":
                                try:
                                    avg_f = float(avg_lat)
                                    if avg_f < best_avg:
                                        best_avg = avg_f
                                        best_ch = ch
                                except ValueError:
                                    continue
                        if best_ch:
                            current_best = await r.get(ROUTE_BEST_KEY.format(agent))
                            if current_best != best_ch:
                                await r.setex(ROUTE_BEST_KEY.format(agent), 86400, best_ch)
                                self._best_channel[agent] = best_ch
                                changes.append(f"↪️ {agent[:8]} → {best_ch} ({best_avg:.0f}ms) [Redis]")

                    # Traffic Class stats
                    tc_keys = await r.keys("tc:stats:*:*")
                    tc_analysed = set()
                    for tc_key in tc_keys:
                        parts = tc_key.split(":")
                        if len(parts) >= 4:
                            traffic_class = parts[2]
                            if traffic_class in tc_analysed:
                                continue
                            tc_analysed.add(traffic_class)
                            best_tc_ch = None
                            best_tc_avg = 9999
                            for ch in ("mesh", "gossip", "nostr", "content_router", "direct"):
                                stats = await r.hgetall(TC_STATS_KEY.format(traffic_class, ch))
                                if not stats:
                                    continue
                                avg_lat = stats.get("avg_latency")
                                if avg_lat and avg_lat != "?":
                                    try:
                                        avg_f = float(avg_lat)
                                        if avg_f < best_tc_avg:
                                            best_tc_avg = avg_f
                                            best_tc_ch = ch
                                    except ValueError:
                                        continue
                            if best_tc_ch:
                                current = await r.get(TC_BEST_KEY.format(traffic_class))
                                if current != best_tc_ch:
                                    await r.setex(TC_BEST_KEY.format(traffic_class), 86400, best_tc_ch)
                                    changes.append(f"🔀 tc:{traffic_class} → {best_tc_ch} ({best_tc_avg:.0f}ms) [Redis]")

                    # Auto-tuning весов политик
                    health_scores = {}
                    for ch, h in self._channel_health.items():
                        total = h["ok"] + h["fail"]
                        if total >= 10:
                            safe_avg = max(1.0, h["avg_ms"])
                            score = h["ok"] / max(1, total) * 100 / safe_avg
                            health_scores[ch] = score
                    if health_scores:
                        max_score = max(health_scores.values())
                        if max_score > 0:
                            for kind_range in await r.hkeys(POLICY_KEY):
                                raw = await r.hget(POLICY_KEY, kind_range)
                                if not raw:
                                    continue
                                weights = json.loads(raw)
                                old_weights = dict(weights)
                                for ch in list(weights.keys()):
                                    ch_score = health_scores.get(ch, 0)
                                    rel_score = ch_score / max_score
                                    if rel_score < 0.3:
                                        weights[ch] = round(weights.get(ch, 0.5) * 0.5, 2)
                                        if weights[ch] < 0.05:
                                            weights[ch] = 0.05
                                    elif rel_score > 0.8:
                                        weights[ch] = round(weights.get(ch, 0.5) * 1.2, 2)
                                        if weights[ch] > 0.95:
                                            weights[ch] = 0.95
                                total_w = sum(weights.values())
                                if total_w > 0:
                                    for ch in weights:
                                        weights[ch] = round(weights[ch] / total_w, 3)
                                if weights != old_weights:
                                    await r.hset(POLICY_KEY, kind_range, json.dumps(weights))
                                    changes.append(f"⚙️ policy {kind_range}: {old_weights} → {weights}")

                else:
                    # ─── Tier 2: In-memory fallback ───
                    healthiest = min(self._channel_health.items(),
                                     key=lambda x: x[1]["avg_ms"] if x[1]["avg_ms"] > 0 else 9999)
                    if healthiest and healthiest[1]["avg_ms"] > 0:
                        best_ch = healthiest[0]
                        for agent in set(self._best_channel.keys()) | {"default"}:
                            current = self._best_channel.get(agent)
                            if current != best_ch:
                                self._best_channel[agent] = best_ch
                                changes.append(f"↪️ best_channel → {best_ch} ({healthiest[1]['avg_ms']:.0f}ms) [in-mem]")
                                break

                # ═══ Блок 3: Сервисные операции ═══
                # Сброс health раз в 5 циклов
                if int(now / self._learning_interval) % 5 == 0:
                    for ch in self._channel_health:
                        self._channel_health[ch] = {"ok": 0, "fail": 0, "avg_ms": 0}

                if changes:
                    for c in changes:
                        print(f"[Router] 📊 {c}")
                    self.stats["learning_actions"] += len(changes)

                # Policy cache reload + sync best channels
                if int(now / self._learning_interval) % 4 == 0:
                    await self._load_policy_cache()
                    await self._sync_best_channels()

                # Flush route stats every ~30s
                if now - self._rs_last_flush >= 30:
                    await self._flush_route_stats()

                # Mesh buffer flush
                if self._mesh_buf and self._cr_writer:
                    try:
                        self._cr_writer.write(bytes(self._mesh_buf))
                        self._mesh_buf.clear()
                        await asyncio.wait_for(self._cr_writer.drain(), timeout=3)
                    except (ConnectionResetError, BrokenPipeError, OSError, asyncio.TimeoutError) as _eb:
                        print(f"[SelfLearn] ⚠️ Mesh writer dead ({_eb}), resetting")
                        self._cr_writer = None
                        self._mesh_buf.clear()

                self._last_learning = now

            except Exception as e:
                print(f"[SelfLearn] Error: {e}")

    async def route_message(self, msg: dict) -> dict:
        self.stats["received"] += 1

        meta = msg.get("meta", {})
        from_agent = msg.get("from", msg.get("pubkey", "?"))[:16]
        to_agent = msg.get("to", "broadcast")[:16]
        kind = msg.get("kind", 39002)
        priority = meta.get("priority", "normal")
        channel_pref = meta.get("channel", "auto")
        
        # ═══ Вектор 3: Self-Learning по traffic_class ═══
        traffic_class = classify_traffic(kind, meta)
        self.stats[f"tc:{traffic_class}"] += 1

        # Шаг 1: выбор канала (с учётом traffic_class + self-learning)
        if channel_pref == "auto":
            # Базовая политика по kind
            policy = self.get_policy(kind)
            
            # Self-learning best канал для traffic_class
            tc_best = await self._get_tc_best(traffic_class)
            
            if tc_best and tc_best in policy:
                channel = tc_best
            else:
                # Default weights для traffic_class
                tc_default = TRAFFIC_CLASSES.get(traffic_class, {"mesh": 1.0})
                # Комбинируем с policy: берём общие каналы с весами из tc
                combined = {ch: tc_default.get(ch, 0.1) for ch in policy}
                chs = list(combined.keys())
                weights = [combined[c] for c in chs]
                channel = random.choices(chs, weights=weights, k=1)[0]
            
            # Фаза 2: если канал зациркуичен — перевыбираем
            if self._cb.is_blocked(channel):
                self.stats["cb_reroute"] += 1
                alt = [c for c in policy if not self._cb.is_blocked(c)]
                channel = alt[0] if alt else "mesh"
            # Фаза 1: если выбранный канал перегружен — перевыбираем
            health = self._channel_health.get(channel)
            if health and health["ok"] + health["fail"] > 5:
                fail_rate = health["fail"] / max(1, health["ok"] + health["fail"])
                if fail_rate > 0.3:
                    alt_channels = [c for c in policy if c != channel and not self._cb.is_blocked(c)]
                    if alt_channels:
                        alt_weights = [policy[c] for c in alt_channels]
                        channel = random.choices(alt_channels, weights=alt_weights, k=1)[0]
                        self.stats["congestion_reroute"] += 1
                elif health["avg_ms"] > 200:
                    self.stats["congestion_slow"] += 1
        elif channel_pref in ("direct", "mesh", "gossip", "nostr", "content_router", "chequebook", "gossip_data", "nostr_data"):
            channel = channel_pref
            # Фаза 2: если явно запрошенный канал зациркуичен — mesh fallback
            if self._cb.is_blocked(channel):
                self.stats["cb_reroute_explicit"] += 1
                channel = "mesh"
        else:
            channel = "mesh"
        
        # ═══ Фаза 1: Reputation-weighted override ═══
        try:
            sender_pubkey = event.get("pubkey", "")
            if sender_pubkey:
                rep_weight = _get_reputation_weight(sender_pubkey)
                if rep_weight < 0.3:
                    # Низкая репутация → только mesh (контролируемый канал)
                    if channel in ("nostr", "gossip", "gossip_data", "nostr_data"):
                        self.stats["rep_low_reroute"] += 1
                        channel = "mesh"
        except Exception:
            pass
        
        # Шаг 2: собираем каналы для отправки (исключая CB-blocked)
        policy = self.get_policy(kind)
        channels_to_try = [ch for ch in [channel] if not self._cb.is_blocked(ch)]
        # ⭐ Fallback: если nostr в каналах — добавляем mesh как резерв
        if 'nostr' in channels_to_try and 'mesh' not in channels_to_try:
            channels_to_try.append('mesh')
        if not channels_to_try:
            channels_to_try = ["mesh"]  # mesh — последняя надежда, даже если blocked
        
        # ═══ Вектор 4: kind:30000 → обязательно шлём в ChequeBook ═══
        if kind == 30000 and "chequebook" not in channels_to_try and not self._cb.is_blocked("chequebook"):
            channels_to_try.append("chequebook")

        # Мультиканал для высокого приоритета
        if priority == "high":
            extra_channels = [c for c in policy if c != channel and not self._cb.is_blocked(c)]
            if not extra_channels:
                extra_channels = [c for c in ("mesh", "gossip", "gossip_data", "nostr", "chequebook") if c != channel and not self._cb.is_blocked(c)]
            channels_to_try.extend(extra_channels[:1])

        self.stats[f"channel:{channel}"] += 1
        self.stats[f"priority:{priority}"] += 1
        self.stats[f"kind:{kind}"] += 1

        # Шаг 3: отправка
        print(f"[Router] 📨 route_message: channel={channel} channels_to_try={channels_to_try} priority={priority}")
        best_result = {"ok": False, "latency_ms": 9999, "error": "no channel"}
        ok_count = 0
        for ch in channels_to_try:
            result = await self.send_via_channel(ch, msg)
            if result["ok"]:
                self._record_route(from_agent, ch, result["latency_ms"], True)
                self._record_tc(traffic_class, ch, result["latency_ms"], True)
                self.stats[f"chan_ok:{ch}"] += 1
                ok_count += 1
                if result["latency_ms"] < best_result["latency_ms"]:
                    best_result = result
                    best_result["channel"] = ch
            else:
                self._record_route(from_agent, ch, result["latency_ms"], False)
                self._record_tc(traffic_class, ch, result["latency_ms"], False)
                self.stats[f"chan_fail:{ch}"] += 1

        # ═══ Content Router мультикаст: все kind дублируются в CR ═══
        if self._cr_v2_writer is None:
            print(f"[Router] ⚠️ CR v2 writer is None, attempting reconnect...")
            try:
                r, w = await asyncio.wait_for(
                    asyncio.open_connection("127.0.0.1", CR_V2_PORT), timeout=1
                )
                self._cr_v2_writer = w
                print(f"[Router] ✅ CR v2 reconnected (:{CR_V2_PORT})")
            except Exception as e:
                print(f"[Router] ❌ CR reconnect failed: {e}")
        if self._cr_v2_writer:
            print(f"[Router] 🔁 CR multicast for kind={msg.get('kind',0)} from={msg.get('from','?')[:12]}")
            try:
                cr_payload = json.dumps(msg) + b"\n"  # orjson returns bytes, no .encode()
                self._cr_v2_writer.write(cr_payload)
                await asyncio.wait_for(self._cr_v2_writer.drain(), timeout=1)
                self.stats["cr_v2_multicast"] += 1
            except Exception as ex:
                print(f"[Router] ❌ CR multicast FAIL: {type(ex).__name__}: {ex}")
                self.stats["cr_v2_multicast_fail"] += 1
                self._cr_v2_writer = None
                # Попробуем переподключиться
                try:
                    r, w = await asyncio.wait_for(
                        asyncio.open_connection("127.0.0.1", CR_V2_PORT), timeout=2
                    )
                    self._cr_v2_writer = w
                except Exception:
                    pass
        
        # Если ничего не сработало — mesh как последняя надежда
        if not best_result["ok"] and "mesh" not in channels_to_try:
            r = await self.send_via_channel("mesh", msg)
            if r["ok"]:
                best_result = r
                best_result["channel"] = "mesh"
                self.stats["fallback_to_mesh"] += 1

        if best_result["ok"]:
            self.stats["forwarded"] += 1
            best_result["channels_used"] = ok_count
        else:
            self.stats["failed"] += 1

        return best_result

    async def handle_client(self, reader, writer):
        peer = writer.get_extra_info("peername", ("?", 0))
        addr = f"{peer[0]}:{peer[1]}"

        # ═══ Фаза 2: Backpressure ═══
        self._concurrent += 1
        self.stats["connections"] += 1
        if self._concurrent > BP_MAX_CONCURRENT:
            self._bp_threshold_reached = True
            self.stats["backpressure_rejected"] += 1
            try:
                bp = {"retry_after": BP_RETRY_AFTER_SEC, "error": "backpressure",
                      "concurrent": self._concurrent, "max": BP_MAX_CONCURRENT}
                writer.write(json.dumps(bp) + b"\n")
                await writer.drain()
            except Exception:
                pass
            writer.close()
            self._concurrent -= 1
            self.stats["disconnects"] += 1
            return
        if self._concurrent > BP_MAX_CONCURRENT * 0.8:
            self.stats["backpressure_warning"] += 1

        try:
            while True:
                line = await asyncio.wait_for(reader.readline(), timeout=30)
                if not line:
                    break
                line = line.decode().strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    self.stats["bad_json"] += 1
                    continue

                # ═══ Фаза 0: verify_sig (optional, 0.05ms) ═══
                sig = msg.get("sig", "")
                pk = msg.get("pubkey", "")
                if sig and pk:
                    payload = msg.get("payload", {})
                    if verify_ed25519(pk, payload, sig):
                        self.stats["signed_ok"] += 1
                        # DHT: регистрируем/обновляем подписанного агента
                        if self._dht:
                            agent_meta = {
                                "role": msg.get("from", "anonymous"),
                                "kind": msg.get("kind", 0),
                                "ip": msg.get("meta", {}).get("ip", "127.0.0.1"),
                                "tcp_port": int(msg.get("meta", {}).get("tcp_port", 9932)),
                            }
                            asyncio.ensure_future(self._safe_dht_refresh(pk, agent_meta))
                    else:
                        self.stats["signed_fail"] += 1
                        writer.write(b'{"ok":false,"error":"invalid sig"}\n')
                        try:
                            await writer.drain()
                        except Exception:
                            pass
                        continue
                else:
                    self.stats["unsigned_packets"] += 1

                # ═══ Фаза 8: Subscribe/Unsubscribe от агентов ═══
                kind = msg.get("kind", 0)
                if kind == "subscribe":
                    sub_id = self._sub_next_id
                    self._sub_next_id += 1
                    agent_name = msg.get("from", "anonymous")
                    self._event_subscribers[sub_id] = (writer, agent_name)
                    self.stats["subscribers"] = len(self._event_subscribers)
                    writer.write(json.dumps({"ok": True, "subscribed": True, "sub_id": sub_id}) + b"\n")
                    await writer.drain()
                    print(f"[Router] ✅ Agent '{agent_name}' subscribed (id={sub_id}, total={len(self._event_subscribers)})")
                    continue
                elif kind == "unsubscribe":
                    sub_id = msg.get("sub_id", -1)
                    agent_name = msg.get("from", "unknown")
                    if sub_id in self._event_subscribers:
                        del self._event_subscribers[sub_id]
                        self.stats["subscribers"] = len(self._event_subscribers)
                        print(f"[Router] ❌ Agent '{agent_name}' unsubscribed (id={sub_id})")
                    writer.write(json.dumps({"ok": True, "unsubscribed": True}) + b"\n")
                    await writer.drain()
                    continue
                
                # ═══ Фаза 9: Push всем подписанным агентам (кроме отправителя) ═══
                from_agent = msg.get("from", "")
                event_for_push = {
                    "type": "push",
                    "kind": kind,
                    "from": from_agent,
                    "pubkey": msg.get("pubkey", ""),
                    "payload": msg.get("payload", msg.get("content", "")),
                    "meta": msg.get("meta", {}),
                    "ts": time.time(),
                }
                await self._push_to_subscribers(event_for_push, exclude_writer=writer)
                
                # pipeline_feed от RE — только push, без роутинга (избегаем цикла RE→SR→CRV2→RE)
                if kind == "pipeline_feed":
                    continue

                result = await self.route_message(msg)
                try:
                    writer.write(json.dumps(result) + b"\n")
                    await writer.drain()
                except (BrokenPipeError, ConnectionResetError):
                    break

        except asyncio.TimeoutError:
            self.stats["client_timeout"] += 1
        except (ConnectionResetError, BrokenPipeError):
            pass
        except Exception as e:
            self.stats["errors"] += 1
        finally:
            # Удаляем подписку этого клиента если была
            dead_ids = [sid for sid, (w, _) in self._event_subscribers.items() if w is writer]
            for sid in dead_ids:
                del self._event_subscribers[sid]
                self.stats["subscribers"] = len(self._event_subscribers)
            writer.close()
            self._concurrent -= 1
            self.stats["disconnects"] += 1

    async def _push_to_subscribers(self, event: dict, exclude_writer=None):
        """Разослать событие всем подписанным агентам."""
        if not self._event_subscribers:
            return
        dead_ids = []
        payload = json.dumps(event) + b"\n"
        for sid, (w, name) in list(self._event_subscribers.items()):
            if w is exclude_writer:
                continue
            try:
                w.write(payload)
                await w.drain()
            except (BrokenPipeError, ConnectionResetError, OSError):
                dead_ids.append(sid)
        for sid in dead_ids:
            del self._event_subscribers[sid]
            self.stats["subscribers"] = len(self._event_subscribers)

    async def _safe_dht_refresh(self, pubkey: str, meta: dict):
        """Безопасный DHT refresh в фоне (catch ошибок)."""
        try:
            if self._dht:
                await self._dht.refresh_agent(pubkey, meta)
        except Exception as e:
            print(f"[DHT] refresh error: {type(e).__name__}: {e}")

    async def run(self):
        global _GLOBAL_ROUTER
        _GLOBAL_ROUTER = self
        await apply_policies()
        await self.ensure_channels()

        # Фаза 6.2: загружаем policy cache при старте
        await self._load_policy_cache()
        await self._sync_best_channels()
        print(f"[Router]    Policy cache: {len(self._policy_cache)} rules (in-memory)")

        # ═══ Фаза 1: DHT Kademlia ═══
        try:
            from dht_node import DHTNode, DHT_PORT
            self._dht = DHTNode(
                port=DHT_PORT,
                agent_pubkey="smart_router",
                agent_meta={"ip": "127.0.0.1", "tcp_port": 9932, "role": "router",
                            "relay_addr": f"127.0.0.1:{self._gossip_stream.listen_port if self._gossip_stream else 9105}"}
            )
            await self._dht.start()
            print(f"[Router] ✅ DHT node ready (agents={len(await self._dht.list_agents())})")
        except Exception as e:
            print(f"[Router] ⚠️ DHT init error: {e}")

        n_gossip = len(self._gossip_writers)
        server = await asyncio.start_server(self.handle_client, LISTEN_HOST, LISTEN_PORT)
        addr = server.sockets[0].getsockname()
        print(f"[Router] 🧠 Smart Router v2 — {addr[0]}:{addr[1]}")
        print(f"[Router]    Channels: mesh ✓ nostr ✓ gossip({n_gossip}/5) direct ✓ gossip_data {'✓' if self._gossip_stream else '✗'}")
        r = await aredis()
        n_policies = len(await r.hkeys(POLICY_KEY)) if r else 0
        print(f"[Router]    Policies: {n_policies} rules in Redis")
        print(f"[Router]    Route-learning: ON")
        print(f"[Router]    Phase 4: orjson + Health :{HEALTH_PORT}")

        async def health_check(reader, writer):
            """HTTP endpoint: /health — общая статистика, /dht — детали DHT."""
            try:
                request_line = await reader.readline()
                path = request_line.decode().split(" ")[1] if b" " in request_line else "/"
                n_clients = len(getattr(self, 'agent_states', {}))
                n_conc = self._concurrent
                r = await aredis()
                redis_ok = r is not None

                if path == "/dht" and self._dht:
                    agents = await self._dht.list_agents()
                    nodes = await self._dht.list_nodes()
                    body = json.dumps({
                        "running": True,
                        "node_id": self._dht.server.node.id.hex() if self._dht.server and self._dht.server.node else "?",
                        "node_pubkey": "smart_router",
                        "agents": agents,
                        "nodes": nodes,
                        "n_agents": len(agents),
                        "n_nodes": len(nodes),
                    })
                elif path == "/dht":
                    body = json.dumps({"running": False})
                else:
                    body = json.dumps({
                    "status": "ok",
                    "uptime": int(time.time() - self.stats.get("start_time", time.time())),
                    "channels": {
                        "mesh": self._cr_writer is not None,
                        "nostr": len(self._nostr_writers),
                        "gossip": sum(1 for w in self._gossip_writers if w is not None),
                        "direct": True,
                    },
                    "clients": n_clients,
                    "concurrent": n_conc,
                    "redis": redis_ok,
                    "dht": {
                        "running": self._dht is not None and self._dht.is_running(),
                        "n_agents": len(await self._dht.list_agents()) if self._dht else 0,
                        "n_nodes": len(await self._dht.list_nodes()) if self._dht else 0,
                    } if self._dht else {"running": False},
                    "stats": {k: v for k, v in self.stats.items()
                              if isinstance(v, (int, float))},
                    "version": "2.4.0",
                })
                resp = (
                    b"HTTP/1.1 200 OK\r\n"
                    b"Content-Type: application/json\r\n"
                    b"Content-Length: " + str(len(body)).encode() + b"\r\n"
                    b"Access-Control-Allow-Origin: *\r\n"
                    b"Connection: close\r\n"
                    b"\r\n" + body
                )
                writer.write(resp)
                await writer.drain()
            except Exception as e:
                err = str(e).encode()
                resp = (
                    b"HTTP/1.1 500 ERROR\r\n"
                    b"Content-Type: text/plain\r\n"
                    b"Content-Length: " + str(len(err)).encode() + b"\r\n"
                    b"\r\n" + err
                )
                writer.write(resp)
                await writer.drain()
            finally:
                writer.close()
        
        health = await asyncio.start_server(health_check, "127.0.0.1", HEALTH_PORT)
        
        async with server, health:
            await asyncio.gather(
                server.serve_forever(),
                health.serve_forever(),
                self.self_learning_loop(),
            )


# ─── Статус ────────────────────────────────────────────────────────────
async def print_status(router: SmartRouter):
    start = time.time()
    while True:
        await asyncio.sleep(30)
        elapsed = int(time.time() - start)
        r = await aredis()

        ch_summary = {}
        if r:
            for ch in ("direct", "mesh", "gossip", "nostr"):
                keys = await r.keys(f"route:stats:*:{ch}")
                ts, tf, tl = 0, 0, []
                for k in keys:
                    h = await r.hgetall(k)
                    ts += int(h.get("sent", 0))
                    tf += int(h.get("failed", 0))
                    avg = h.get("avg_latency")
                    if avg and avg != "?":
                        tl.append(float(avg))
                al = round(sum(tl) / len(tl), 1) if tl else 0
                ch_summary[ch] = {"sent": ts, "failed": tf, "avg_ms": al}

        print(f"\n[Router] {'='*55}")
        print(f"[Router] Uptime: {elapsed}s | Msgs: recv={router.stats['received']} "
              f"fwd={router.stats['forwarded']} fail={router.stats['failed']}")
        print(f"[Router] Concurrent: {router._concurrent}/{BP_MAX_CONCURRENT} | "
              f"BP: rejected={router.stats['backpressure_rejected']} warn={router.stats['backpressure_warning']}")
        print(f"[Router] CB: reroute={router.stats['cb_reroute']} blocked={router.stats['cb_blocked']} | "
              f"timeouts: mesh={router.stats['timeout:mesh']} gossip={router.stats['timeout:gossip']} "
              f"nostr={router.stats['timeout:nostr']}")
        blocked_channels = router._cb.get_blocked()
        if blocked_channels:
            print(f"[Router] 🔴 Blocked channels: {', '.join(blocked_channels)} (30s)")
        print(f"[Router] Channels: mesh={router.stats['chan_ok:mesh']} "
              f"gossip={router.stats['chan_ok:gossip']} "
              f"nostr={router.stats['chan_ok:nostr']} "
              f"direct={router.stats['chan_ok:direct']}")
        print(f"[Router] Fallbacks: {router.stats['fallback_to_mesh']} | "
              f"congestion_reroute: {router.stats['congestion_reroute']} | "
              f"congestion_slow: {router.stats['congestion_slow']}")
        print(f"[Router] Channel health (last cycle):")
        for ch, h in router._channel_health.items():
            total = h["ok"] + h["fail"]
            if total:
                bar = "█" * max(1, int(h["avg_ms"] / 10)) if h["avg_ms"] else "?"
                print(f"  {ch:8s} ok={h['ok']} fail={h['fail']} avg={h['avg_ms']:.0f}ms {bar}")
            else:
                print(f"  {ch:8s} — no data")
        print(f"[Router] Redis delivery stats:")
        for ch, s in ch_summary.items():
            bar = "█" * max(1, int(s["avg_ms"] / 10)) if s["avg_ms"] else "?"
            print(f"  {ch:8s} → sent={s['sent']} fail={s['failed']} avg={s['avg_ms']}ms {bar}")
        print(f"[Router] {'='*55}\n")


async def health_server():
    """HTTP health endpoint для L2 Transport — на HEALTH_PORT (9933)"""
    import asyncio
    reader_writers = []
    server = await asyncio.start_server(
        lambda r, w: reader_writers.append((r, w)),
        '127.0.0.1', HEALTH_PORT
    )
    async with server:
        print(f"[Router] ✅ Health HTTP endpoint on :{HEALTH_PORT}")
        async for client_reader, client_writer in server.accept():
            try:
                request = await asyncio.wait_for(client_reader.read(1024), timeout=2)
                if request:
                    router = _GLOBAL_ROUTER if '_GLOBAL_ROUTER' in dir() else None
                    alive_channels = 0
                    total_channels = 0
                    if router and hasattr(router, '_channel_health'):
                        for ch, h in router._channel_health.items():
                            total_channels += 1
                            if h.get('ok', 0) > h.get('fail', 0):
                                alive_channels += 1
                    response = (
                        "HTTP/1.1 200 OK\r\n"
                        "Content-Type: application/json\r\n"
                        "Connection: close\r\n"
                        f"Content-Length: 0\r\n\r\n"
                    ).encode()
                    client_writer.write(response)
                    await client_writer.drain()
            except: pass
            finally:
                try: client_writer.close()
                except: pass


async def main():
    router = SmartRouter()
    
    # Запуск GossipStream (V8 data channel)
    try:
        gs = GossipStream(pubkey="sr_gossip_v8")
        await gs.start_server_async()
        router._gossip_stream = gs
        print(f"[Router] ✅ GossipStream V8 on :{gs.listen_port}")
    except Exception as e:
        print(f"[Router] ⚠️ GossipStream V8: {e}")
    
    try:
        await asyncio.gather(router.run(), print_status(router), router._dht_scan_loop())
    except Exception as e:
        import traceback
        print(f"[Router] 💀 Main loop crashed: {e}")
        print(traceback.format_exc())
        raise


if __name__ == "__main__":
    import sys
    print(f"[Router] Smart Router v2 — multi-channel, policy + self-learning")
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print(f"[Router] Shutdown")
    except asyncio.CancelledError:
        print(f"[Router] Cancelled")
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        print(f"[Router] 💀 FATAL CRASH: {e}")
        print(f"[Router] Traceback:\n{tb}")
        sys.exit(1)
