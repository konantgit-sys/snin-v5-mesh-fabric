# SNIN Relay Mesh — Архитектура V1-V6

**Дата:** 2026-05-18
**Статус:** ✅ Production (12 демонов, 10 портов, все слои активны)

---

## Концепция

Многослойная P2P mesh-сеть, где каждый агент = отдельное реле с полной копией архитектуры. 
Сервер — одно из реле в сети. Взаимодействие между реле — через gossip, Nostr, mesh.

---

## 7 уровней архитектуры

### Уровень 7: Smart Router (:9932) — роутер
**Файл:** `smart_router.py`
**Назначение:** Выбор маршрута для каждого сообщения на основе self-learning

Классификация по kind:
```
kind:39000 (heartbeat)    → gossip
kind:39001 (dht)          → mesh  
kind:39002 (content)      → nostr + CR
kind:30000 (payment)      → chequebook + mesh
kind:39010 (dao)          → mesh
```

Self-learning: анализирует latency + fail rate каждого канала.
Хранит `route:history:*:*` — 62 ключа в Redis.
При CB fail_rate > 50% — наказывает канал (снижает вес).

### Уровень 6: Nostr Bridge — внешний мир
**Файл:** `nostr_bridge.py`
**Назначение:** 101 релей, публикация kind:39002 во внешнюю Nostr-сеть

Async I/O, параллельная запись во все релеи.
Только outbound (публикация). Чтение — через NIP-01 subscription.

### Уровень 5: Content Router (:9920) — дедупликация
**Файл:** `content_router_v2.py`
**Назначение:** Фильтрация дубликатов + forward в Route Engine

Трёхфазная дедупликация:
1. FastDedup — in-memory set (0.5µs)
2. Bloom filter — страховка (O(1))
3. Redis — cross-instance (150µs)

Writer pool к RE: N_WRITERS, round-robin, drain каждые 20ms.
Unix socket (/tmp/snin/cr.sock) → TCP fallback (:9910).

### Уровень 4: Route Engine (:9910) — маршрутизация mesh
**Файл:** `route_engine.py`
**Назначение:** Маршрутизация mesh-сообщений, WebSocket bridge

WebSocket (`ws://127.0.0.1:9908`) с RFC 6455 ping/pong.
Batch окно: 0.1s (группировка событий перед отправкой).
Fallback на HTTP при потере WS.

### Уровень 3: Mesh + REST API (:9907)
**Файл:** `app.py`
**Назначение:** Flask-приложение, REST API + NIP-42 WebSocket

Endpoints:
- `/health` — healthcheck
- `/agents` — список агентов
- `/mesh/stats` — статистика
- `/mesh/send` — отправка в mesh
- `/agents/register` — регистрация агента
- `/network/snapshot` — снимок сети
- `/system/degradation` — статус деградации

### Уровень 2: Gossip ×5 — синхронизация
**Файлы:** `gossip_shard.py --shard-id {0-4}`
**Назначение:** 5 параллельных gossip-воркеров, шардированная отправка

heartbeat (kind:39000) каждые 30 сек.
5 воркеров, каждый на своём порту (9100-9104).
Random peer selection при каждом heartbeat.

### Уровень 1: Экономический слой

**ChequeBook (:9916)** — чековые книжки.
- Файл: `cheque_book_v2.py`
- 15 книг issued, 8 агентов с книгами, 150000 чеков

**Verifier (:9915)** — верификация Solana.
- Файл: `verifier.py`
- Асинхронная верификация через Solana mainnet RPC
- 5 транзакций обработано

**payment_handler** — kind:30000.
- Валидация + очередь `/dev/shm/payment_queue.jsonl`
- 6 платежей в очереди

**Solana RPC** — `api.mainnet-beta.solana.com`, blockhash получен ✅

### Уровень 0: Обнаружение + DAO

**First Contact (mesh_service_daemon)** — Вектор 5.
- Сканирование 7 каналов: mesh, api, route_engine, content_router, nostr, tcp, gossip
- Построение матрицы маршрутов
- Регистрация в Redis DHT
- 1 цикл = 90-194ms, интервал 30s

**DAO Bridge (mesh_service_daemon)** — Вектор 6.
- Опрос Chrono (http://localhost:8190)
- При passed proposal с action=relay_mesh — allowlist_set / dht_put
- Интервал 60s

---

## Схема потоков данных

```
PipelineFeeder
     ↓ kind:39002
SR (:9932) → классификация → выбор канала
     ↓
CR (:9920) → dedup → forward
     ↓ Unix/TCP  
RE (:9910) → batch (0.1s) → WS
     ↓ WebSocket
WS Server (:9908) → IngestWS
     ↓
Mesh API (:9907) → агенты

Parallel send (предложено):
     SR → [Nostr, gossip, mesh] одновременно
     CR dedup на приёмной стороне
```

---

## Портовая карта

| Порт | Компонент | Протокол | Назначение |
|:----:|-----------|----------|------------|
| 9907 | app.py | HTTP/WS | REST API + NIP-42 |
| 9908 | ws_server.py | WS (RFC 6455) | WebSocket bridge |
| 9910 | route_engine.py | TCP/Unix | Route Engine |
| 9915 | verifier.py | HTTP | Solana верификация |
| 9916 | cheque_book_v2.py | HTTP | Чековые книжки |
| 9920 | content_router_v2.py | TCP/Unix | Content Router |
| 9931 | external_gateway.py | TCP | IoT/External шлюз |
| 9932 | smart_router.py | TCP | Smart Router |
| 9100-9104 | gossip_shard.py | TCP | Gossip 5 воркеров |
| 8190 | chrono | HTTP | DAO proposals |

---

## Технические метрики

| Метрика | Значение | Дата |
|---------|----------|------|
| Версия | v2 (NIP-42) | — |
| Демонов | 12 | 2026-05-18 |
| Строк кода | ~13000 (43 файла) | 2026-05-18 |
| Агентов в DHT | 3 (forecaster, archivist, router) | 2026-05-18 |
| Чековых книг | 15 | 2026-05-18 |
| Nostr релеев | 101 | 2026-05-18 |
| Redis DHT ключей | dht:agents + dht:agent:* | 2026-05-18 |
| ulimit | 65535 | 2026-05-18 (фикс) |
| TCP ESTAB | ~270 (после фикса утечки) | 2026-05-18 |

---

## Производительность (оценка)

| Сценарий | msg/sec | Узкое место |
|----------|:-------:|-------------|
| Local (одно реле) | ~50 | SR CPU |
| Cross-relay (parallel send) | ~35-50 | Gossip data channel |
| Pure Nostr | ~2 | 101 релей × 500ms |
| Gossip direct (после улучшения) | ~500 | TCP между серверами |

---

## История векторов

| Вектор | Статус | Дата |
|--------|:------:|------|
| V1 — Smart Router | ✅ | 2026-05 |
| V2 — Content Router | ✅ | 2026-05 |
| V3 — Route Engine | ✅ | 2026-05 |
| V4 — Экономический слой | ✅ | 2026-05 |
| V5 — First Contact | ✅ | 2026-05-03 |
| V6 — DAO Bridge | ✅ | 2026-05-03 |
| V7 — Утечка CR (hotfix) | ✅ | 2026-05-18 |
